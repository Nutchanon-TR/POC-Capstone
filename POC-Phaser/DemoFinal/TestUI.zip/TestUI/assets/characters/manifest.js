window.CONNECTA_CHARACTERS = [
  {
    "id": "character-01",
    "name": "Mika",
    "group": "Campus friends",
    "walk": "assets/characters/character-01-walk.png",
    "idle": null,
    "source": "D:\\A_SIT04\\SIT4-TERM1\\a_M_CapStone\\BussinessMd\\MyMdTool\\ImageGenerate\\CharacterGenerate\\Example01-sprites\\ChatGPT Image Oct 15, 2026, 11_51_51 PM.png",
    "idleSource": null,
    "directions": [
      "down",
      "up",
      "left",
      "right"
    ],
    "columns": 4,
    "rows": 4,
    "frameSize": 80,
    "idleMode": "breathing"
  },
  {
    "id": "character-02",
    "name": "Haru",
    "group": "Campus friends",
    "walk": "assets/characters/character-02-walk.png",
    "idle": null,
    "source": "D:\\A_SIT04\\SIT4-TERM1\\a_M_CapStone\\BussinessMd\\MyMdTool\\ImageGenerate\\CharacterGenerate\\Example01-sprites\\ChatGPT Image Oct 15, 2026, 11_52_19 PM.png",
    "idleSource": null,
    "directions": [
      "down",
      "up",
      "left",
      "right"
    ],
    "columns": 4,
    "rows": 4,
    "frameSize": 80,
    "idleMode": "breathing"
  },
  {
    "id": "character-03",
    "name": "Nami",
    "group": "Campus friends",
    "walk": "assets/characters/character-03-walk.png",
    "idle": null,
    "source": "D:\\A_SIT04\\SIT4-TERM1\\a_M_CapStone\\BussinessMd\\MyMdTool\\ImageGenerate\\CharacterGenerate\\Example01-sprites\\ChatGPT Image Oct 15, 2026, 11_52_26 PM.png",
    "idleSource": null,
    "directions": [
      "down",
      "up",
      "left",
      "right"
    ],
    "columns": 4,
    "rows": 4,
    "frameSize": 80,
    "idleMode": "breathing"
  },
  {
    "id": "character-04",
    "name": "Ren",
    "group": "Campus friends",
    "walk": "assets/characters/character-04-walk.png",
    "idle": null,
    "source": "D:\\A_SIT04\\SIT4-TERM1\\a_M_CapStone\\BussinessMd\\MyMdTool\\ImageGenerate\\CharacterGenerate\\Example01-sprites\\ChatGPT Image Oct 15, 2026, 11_52_29 PM.png",
    "idleSource": null,
    "directions": [
      "down",
      "up",
      "left",
      "right"
    ],
    "columns": 4,
    "rows": 4,
    "frameSize": 80,
    "idleMode": "breathing"
  },
  {
    "id": "character-05",
    "name": "Sora",
    "group": "Campus friends",
    "walk": "assets/characters/character-05-walk.png",
    "idle": null,
    "source": "D:\\A_SIT04\\SIT4-TERM1\\a_M_CapStone\\BussinessMd\\MyMdTool\\ImageGenerate\\CharacterGenerate\\Example01-sprites\\ChatGPT Image Oct 15, 2026, 11_52_31 PM.png",
    "idleSource": null,
    "directions": [
      "down",
      "up",
      "left",
      "right"
    ],
    "columns": 4,
    "rows": 4,
    "frameSize": 80,
    "idleMode": "breathing"
  },
  {
    "id": "character-06",
    "name": "Yuki",
    "group": "Campus friends",
    "walk": "assets/characters/character-06-walk.png",
    "idle": null,
    "source": "D:\\A_SIT04\\SIT4-TERM1\\a_M_CapStone\\BussinessMd\\MyMdTool\\ImageGenerate\\CharacterGenerate\\Example01-sprites\\ChatGPT Image Oct 15, 2026, 11_52_34 PM.png",
    "idleSource": null,
    "directions": [
      "down",
      "up",
      "left",
      "right"
    ],
    "columns": 4,
    "rows": 4,
    "frameSize": 80,
    "idleMode": "breathing"
  },
  {
    "id": "character-07",
    "name": "Mali",
    "group": "Campus friends",
    "walk": "assets/characters/character-07-walk.png",
    "idle": null,
    "source": "D:\\A_SIT04\\SIT4-TERM1\\a_M_CapStone\\BussinessMd\\MyMdTool\\ImageGenerate\\CharacterGenerate\\Example01-sprites\\Student02.png",
    "idleSource": null,
    "directions": [
      "down",
      "up",
      "left",
      "right"
    ],
    "columns": 4,
    "rows": 4,
    "frameSize": 80,
    "idleMode": "breathing"
  },
  {
    "id": "character-08",
    "name": "Nont",
    "group": "Campus friends",
    "walk": "assets/characters/character-08-walk.png",
    "idle": null,
    "source": "D:\\A_SIT04\\SIT4-TERM1\\a_M_CapStone\\BussinessMd\\MyMdTool\\ImageGenerate\\CharacterGenerate\\Example01-sprites\\StudentBoy01.png",
    "idleSource": null,
    "directions": [
      "down",
      "up",
      "left",
      "right"
    ],
    "columns": 4,
    "rows": 4,
    "frameSize": 80,
    "idleMode": "breathing"
  },
  {
    "id": "character-09",
    "name": "Phum",
    "group": "The university crew",
    "walk": "assets/characters/character-09-walk.png",
    "idle": "assets/characters/character-09-idle.png",
    "source": "D:\\A_SIT04\\SIT4-TERM1\\a_M_CapStone\\BussinessMd\\MyMdTool\\ImageGenerate\\CharacterGenerate\\Example02-sprites\\r1c1-male-student-shoulder-bag-walk-4x4.png",
    "idleSource": "D:\\A_SIT04\\SIT4-TERM1\\a_M_CapStone\\BussinessMd\\MyMdTool\\ImageGenerate\\CharacterGenerate\\Example02-sprites\\r1c1-male-student-shoulder-bag-idle-4x4.png",
    "directions": [
      "down",
      "up",
      "left",
      "right"
    ],
    "columns": 4,
    "rows": 4,
    "frameSize": 80,
    "idleMode": "sheet"
  },
  {
    "id": "character-10",
    "name": "Prae",
    "group": "The university crew",
    "walk": "assets/characters/character-10-walk.png",
    "idle": "assets/characters/character-10-idle.png",
    "source": "D:\\A_SIT04\\SIT4-TERM1\\a_M_CapStone\\BussinessMd\\MyMdTool\\ImageGenerate\\CharacterGenerate\\Example02-sprites\\r1c2-female-student-teal-tote-walk-4x4.png",
    "idleSource": "D:\\A_SIT04\\SIT4-TERM1\\a_M_CapStone\\BussinessMd\\MyMdTool\\ImageGenerate\\CharacterGenerate\\Example02-sprites\\r1c2-female-student-teal-tote-idle-4x4.png",
    "directions": [
      "down",
      "up",
      "left",
      "right"
    ],
    "columns": 4,
    "rows": 4,
    "frameSize": 80,
    "idleMode": "sheet"
  },
  {
    "id": "character-11",
    "name": "Dr. Arun",
    "group": "The university crew",
    "walk": "assets/characters/character-11-walk.png",
    "idle": "assets/characters/character-11-idle.png",
    "source": "D:\\A_SIT04\\SIT4-TERM1\\a_M_CapStone\\BussinessMd\\MyMdTool\\ImageGenerate\\CharacterGenerate\\Example02-sprites\\r2c3-male-lecturer-charcoal-suit-walk-4x4.png",
    "idleSource": "D:\\A_SIT04\\SIT4-TERM1\\a_M_CapStone\\BussinessMd\\MyMdTool\\ImageGenerate\\CharacterGenerate\\Example02-sprites\\r2c3-male-lecturer-charcoal-suit-idle-4x4.png",
    "directions": [
      "down",
      "up",
      "left",
      "right"
    ],
    "columns": 4,
    "rows": 4,
    "frameSize": 80,
    "idleMode": "sheet"
  },
  {
    "id": "character-12",
    "name": "Dr. Pim",
    "group": "The university crew",
    "walk": "assets/characters/character-12-walk.png",
    "idle": "assets/characters/character-12-idle.png",
    "source": "D:\\A_SIT04\\SIT4-TERM1\\a_M_CapStone\\BussinessMd\\MyMdTool\\ImageGenerate\\CharacterGenerate\\Example02-sprites\\r2c4-female-lecturer-gray-suit-walk-4x4.png",
    "idleSource": "D:\\A_SIT04\\SIT4-TERM1\\a_M_CapStone\\BussinessMd\\MyMdTool\\ImageGenerate\\CharacterGenerate\\Example02-sprites\\r2c4-female-lecturer-gray-suit-idle-4x4.png",
    "directions": [
      "down",
      "up",
      "left",
      "right"
    ],
    "columns": 4,
    "rows": 4,
    "frameSize": 80,
    "idleMode": "sheet"
  },
  {
    "id": "character-13",
    "name": "Fah",
    "group": "The university crew",
    "walk": "assets/characters/character-13-walk.png",
    "idle": "assets/characters/character-13-idle.png",
    "source": "D:\\A_SIT04\\SIT4-TERM1\\a_M_CapStone\\BussinessMd\\MyMdTool\\ImageGenerate\\CharacterGenerate\\Example02-sprites\\r3c2-female-staff-burgundy-blazer-walk-4x4.png",
    "idleSource": "D:\\A_SIT04\\SIT4-TERM1\\a_M_CapStone\\BussinessMd\\MyMdTool\\ImageGenerate\\CharacterGenerate\\Example02-sprites\\r3c2-female-staff-burgundy-blazer-idle-4x4.png",
    "directions": [
      "down",
      "up",
      "left",
      "right"
    ],
    "columns": 4,
    "rows": 4,
    "frameSize": 80,
    "idleMode": "sheet"
  },
  {
    "id": "character-14",
    "name": "Dr. May",
    "group": "The university crew",
    "walk": "assets/characters/character-14-walk.png",
    "idle": "assets/characters/character-14-idle.png",
    "source": "D:\\A_SIT04\\SIT4-TERM1\\a_M_CapStone\\BussinessMd\\MyMdTool\\ImageGenerate\\CharacterGenerate\\Example02-sprites\\r3c4-female-lecturer-navy-skirt-walk-4x4.png",
    "idleSource": "D:\\A_SIT04\\SIT4-TERM1\\a_M_CapStone\\BussinessMd\\MyMdTool\\ImageGenerate\\CharacterGenerate\\Example02-sprites\\r3c4-female-lecturer-navy-skirt-idle-4x4.png",
    "directions": [
      "down",
      "up",
      "left",
      "right"
    ],
    "columns": 4,
    "rows": 4,
    "frameSize": 80,
    "idleMode": "sheet"
  }
];
